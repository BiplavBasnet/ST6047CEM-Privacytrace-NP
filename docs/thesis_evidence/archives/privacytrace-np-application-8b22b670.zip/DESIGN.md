---
name: PrivacyTrace-NP
description: Security operations console for masked privacy incidents in Nepal DFS API logs.
colors:
  navy: "#172826"
  brand: "#294743"
  accent: "#0f766e"
  accent-soft: "#dff3f0"
  surface: "#eef1f1"
  surface-card: "#ffffff"
  surface-raised: "#fbfcfc"
  sidebar: "#172826"
  ink: "#17211f"
  ink-muted: "#62706d"
  ink-subtle: "#87938f"
  hairline: "#e2e8f0"
  danger: "#dc2626"
  warning: "#d97706"
  success: "#0f766e"
typography:
  title:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "1.375rem"
    fontWeight: 600
    lineHeight: 1.25
    letterSpacing: "-0.02em"
  body:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "0.8125rem"
    fontWeight: 500
    lineHeight: 1.4
  mono:
    fontFamily: "IBM Plex Mono, ui-monospace, SFMono-Regular, monospace"
    fontSize: "0.75rem"
    fontWeight: 500
rounded:
  sm: "0.25rem"
  md: "0.375rem"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
components:
  button-primary:
    backgroundColor: "{colors.navy}"
    textColor: "#ffffff"
    rounded: "{rounded.sm}"
    padding: "6px 12px"
  button-secondary:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.navy}"
    rounded: "{rounded.sm}"
    padding: "6px 12px"
---

# PrivacyTrace-NP Design System

<!-- Hallmark · designed-as-app · genre: modern-minimal · theme: incumbent-navy-teal -->

## Overview

PrivacyTrace is an **Operate** surface: a Wazuh-inspired security operations console for privacy investigations, not a marketing dashboard. Personality: precise, calm, technical, trustworthy, professional, human-governed.

North star: an analyst should answer, within a few seconds — where am I, what is happening, what needs attention, what should I do next, why, and where is the technical detail.

Do not clone Wazuh, Linear, Sentry, Figma, or Stripe. Borrow operational hierarchy and density only.

## Colors

Retain incumbent navy/teal. Navigation is deep navy `#172826`. Accent `#0f766e` is for the primary action, current nav, and live status — not decoration. Semantic red/amber/teal for danger/warning/success, always with an icon and label.

Forbidden: neon matrix green, purple AI gradients, glassmorphism, decorative radial blooms, thick left-stripe KPI cards.

## Typography

One UI family (Inter) with a tight 1.125–1.2 scale. IBM Plex Mono only for IDs, tokens, payloads, and technical identifiers. No italic headings.

- Page title: 22–26px semibold
- Section: 16–18px semibold
- Body: 14–15px
- Table: 13–14px
- Metadata / technical IDs: 12–13px mono

Never shrink text merely to fit more content. Default operational copy is one short sentence.

## Layout

App shell: navy left sidebar + thin top bar + main `max-w-[1600px]`. Skip-to-main is required.

Global nav groups: Operations, Data & sources, Management, Reference, Help. No desktop “More” junk drawer.

Incident workspace: identity row + compact stage tabs + 70/30 main/context. One next action.

Spacing: 4 / 8 / 12 / 16 / 24 / 32. Prefer sections and tables over stacked padded cards.

Desktop/laptop first (1366, 1440, 1920). Do not spend a mobile redesign pass.

## Elevation & Depth

Hairline borders. Almost no shadows. Dialogs use `shadow-panel`. No nested cards. Collapsible sections are disclosures, not elevated cards.

## Shapes

Radius 4–6px controls, 6–8px panels. Buttons are rectangles, not pills. Status chips are `rounded`, not `rounded-full`. Focus: 2px accent ring with offset.

## Components

### Buttons

One visually dominant primary per operational surface (`btn-primary`). Secondary `btn-secondary`. Destructive `btn-danger` with confirmation. Ghost for quiet actions. Never five equal blue buttons.

### Forms

Visible labels (`field-label` + `field-control`). Controlled inputs. Disabled + loading states. Do not use placeholder as the only label.

### Tables

Toolbar filters (`FilterBar` / `QueueToolbar`). Row height ~40–44px. Selected row `is-selected`. Row may open `DetailInspector`. `overflow-x-auto` on narrower laptops. Audit logs stay dense.

### Cards

Use only when a real grouping exists (invite form, selected diagnosis, export block). Default to sections, dividers, lists, tables, split panes.

### Inspector / dialogs

One `DetailInspector` for alert, event, user, and audit detail (desktop right pane). Native `<dialog>` (`ConfirmDialog`) for destructive or sensitive confirmation only.

### Disclosures

`<details>` / `CollapsibleSection` / `SegmentedTabs` for advanced technical content. Critical warnings and required decisions stay open.

### Empty / error / blocked

Answer what happened, why, and what the user can do. Permission denied names the role. Blocked workflow names the missing gate. No stack traces. No decorative empty illustrations.

### Workflow

Identity row (title, safe ID, severity, status, service). Compact stage tabs. **One** next action from backend `next_action`. If the user is already on that stage, the stage body owns the operational primary. TEST PASSED ≠ FIX VERIFIED. Rollback is never a green success.

### Status

`StatusBadge` only: icon + human label + color. Technical enum in `title`.

## UX principles

- Progressive disclosure: always visible → secondary → advanced.
- Plain language in the UI; backend names in details.
- Centralise safety notices (`CompactSafetyNotice`) once per page.
- Do not repeat next-action, ID, or thesis paragraphs.

## Navigation model

- Global: what area of PrivacyTrace.
- Incident: which investigation stage.
- Next action: what to do now.
- Deep links and aliases remain valid.

## Copy style

Prefer “3 alerts need review.” over essays. Prefer “Why this cause?” over five permanent paragraphs. Cautious wording: likely cause, evidence supports, evidence weakens, more evidence needed, verification passed based on controlled retest. Never: proven cause, guaranteed fix, AI fixed it, confirmed blame.

## Motion

150–250ms opacity/transform only. Respect `prefers-reduced-motion`. No page-load choreography.

## Accessibility

WCAG 2.2 AA. Keyboard order matches visual order. Visible `:focus-visible`. Form labels. Dialog focus. Disclosure/tab semantics. Touch targets ≥ 36–44px on mobile controls.

## Anti-patterns

Card soup; card-in-card; giant in-app heroes; KPI tile grids; competing primary CTAs; repeating safety essays; glass nav; neon/cyberpunk; color-only status; hiding destructive actions in unlabeled menus; inventing workflow completion in React state; vague “More” nav on desktop.

## Do's and Don'ts

- Do keep every route and capability reachable.
- Do evolve navy/teal rather than replacing it.
- Don't install shadcn/Radix/TanStack/Framer Motion unless an existing primitive cannot do the job.
- Don't change backend behaviour to make the UI simpler.
