# AGENTS.md — PrivacyTrace-NP

## Project purpose

PrivacyTrace-NP is a Bachelor-level cybersecurity and privacy-engineering research prototype for Nepalese digital financial services.

Main workflow:

Evidence ingestion
→ sensitive-data and credential detection
→ Nepal-specific classification
→ masking and pseudonymisation
→ evidence provenance
→ likely root-cause analysis
→ privacy-harm and breach-severity assessment
→ internal alerting
→ human-reviewed containment and notification decisions
→ preventive controls
→ fix verification
→ safe reporting

Do not describe the project as legally compliant, regulator-certified, autonomous, production-ready, or capable of proving real-world causation.

## Repository structure

Inspect the actual repository before editing.
 
Expected structure:

- `backend/` — FastAPI, SQLAlchemy, PostgreSQL and Alembic
- `backend/app/models/` — database models
- `backend/app/schemas/` — Pydantic schemas
- `backend/app/routers/` — API routes
- `backend/app/services/` — business logic
- `backend/app/rules/` — detection, taxonomy, causality and policy rules
- `backend/alembic/` — migrations
- `backend/tests/` — backend tests
- `frontend/` — React and TypeScript
- `frontend/src/api/` — API clients
- `frontend/src/components/` — reusable components
- `frontend/src/pages/` — pages
- `docs/` — architecture, security, methods, testing and limitations
- `scripts/` — setup, testing and release scripts

Follow existing naming and architecture when paths differ.

## Mandatory working process

Before changing code:

1. Read this file fully.
2. Inspect related models, schemas, routers, services, migrations, components and tests.
3. Trace the full call path.
4. Check whether the requested feature already exists.
5. Reuse or extend existing components instead of duplicating them.
6. Produce a concise plan for complex work.
7. List expected files to change.
8. Identify migration, security and compatibility risks.
9. Make the smallest coherent change.
10. Add or update tests.
11. Run static checks and relevant tests.
12. Update documentation.
13. Report exact results honestly.

Do not:

- rewrite unrelated modules
- add unrelated features during repair work
- create a second architecture
- hide failures with broad exception handling
- weaken assertions
- replace failures with skips
- claim tests passed unless executed
- describe skipped tests as verified
- trust historical reports without rerunning checks

## Security and privacy

- Never commit `.env` with real values.
- Never commit API keys, passwords, tokens, private keys or real credentials.
- Never commit real customer data.
- Use synthetic data in tests and demonstrations.
- Never log raw sensitive information.
- Never place raw sensitive information in exceptions, audit records, reports, AI prompts, webhooks or notification drafts.
- Never send restricted AML information to an external AI provider.
- Enforce RBAC in the backend.
- Do not rely on frontend hiding alone.
- Use masked values in user-facing output.
- Use keyed HMAC fingerprints for stable comparison of predictable identifiers.
- Do not use plain SHA-256 alone for phone numbers, citizenship numbers, dates of birth or account numbers.
- Do not make external network calls in automated tests.
- Do not print secrets or tokens in the browser console.

## Authentication and registration

Use the existing authentication architecture.

- Never store plaintext passwords.
- Never return password hashes.
- Never log passwords or tokens.
- Use the existing password-hashing service.
- Normalise email addresses consistently.
- Prevent duplicate accounts under email case variations.
- Public registration must not accept role or permission fields.
- Public registration must assign the least-privileged existing role, such as `viewer` or `pending`.
- Public registration must never grant administrator, security lead, incident manager, AML officer, privacy officer, auditor, DevSecOps or another privileged role.
- Preserve existing token, refresh-token, cookie and session behaviour.
- Do not place tokens in URLs.
- Use generic login-failure messages.
- Do not show fake OAuth buttons.
- Do not show a dead forgot-password link.
- Audit login and registration without passwords or tokens.

## Restricted AML handling

Treat these as internal-only:

- suspicious activity flags
- STR or SAR status and references
- AML investigation notes
- FIU submission references
- sanctions or watchlist investigation details
- confidential law-enforcement request details

They must not appear in customer notifications, general reports, general webhooks, external AI prompts, unauthorised API responses or ordinary frontend views.

When classification is uncertain, fail closed and omit questionable content from external output.

## Terminology

Keep separate:

- `Detection` — a sensitive-looking value was identified
- `Exposure` — data appeared in an unexpected or unsafe context
- `Suspected breach` — evidence suggests possible unauthorised access or disclosure
- `Verified breach` — authorised human review confirms sufficient evidence
- `Root-cause rule score` — rule-based ranking output
- `Breach severity` — seriousness of incident circumstances
- `Privacy harm` — possible impact on people
- `Alert severity` — operational urgency

A detector match must not automatically become a confirmed breach.

Do not describe rule scores as calibrated probabilities unless calibration is empirically completed and documented.

## Evidence and causality

- Supporting evidence must be cause-specific.
- Do not attach all incident evidence to every cause.
- Keep supporting, contextual, contradictory, remediation and retest evidence separate.
- Retest and remediation evidence must not strengthen the original cause.
- Duplicate evidence must not inflate scores.
- Contradictory evidence must be shown and considered.
- Every score contribution must identify the rule, version, evidence and reason.
- Do not claim proven causation.
- Use cautious wording such as `likely cause`, `possible cause` and `insufficient evidence`.

## Nepal-specific taxonomy

The taxonomy must be configuration-driven and versioned.

It may cover citizenship and National ID data, KYC documents, bank and wallet information, payment-card information, customer credentials, transaction and beneficiary information, restricted AML information, merchant KYC and combined exposure profiles.

Rules:

- Use contextual validation for ambiguous identifiers.
- Do not classify every long number as citizenship.
- Do not classify every four-digit number as a PIN.
- Do not classify every six-digit number as an OTP.
- Do not classify every three-digit number as a CVV.
- Use Luhn validation plus context for payment cards.
- Entropy alone must not validate a credential.
- Do not combine unrelated subjects.
- Record taxonomy and rule-set versions.
- Preserve internal-only handling.
- Do not claim complete Nepali-language coverage unless tested.
- Prefer one shared classification pipeline across evidence upload, Live Monitor, ScannerBridge and SIEM ingestion.

## Evidence provenance

- Keep one authoritative implementation of each public provenance function.
- Do not leave duplicate function definitions.
- Do not use undefined transaction or return variables.
- Define transaction ownership clearly.
- Use deterministic content hashing.
- Do not store raw sensitive data in provenance metadata.
- Validate parent-child relationships.
- Reject circular relationships.
- Record parser, collector and service versions.
- Ensure provenance failure does not leave partial database writes.

## Integrity verification

- Integrity records must be append-only.
- Never silently rewrite historical hashes.
- Use deterministic canonical serialisation.
- Detect modification, missing records, sequence gaps and reordering.
- Use PostgreSQL-safe sequence allocation.
- Scope verification accurately.
- Integrity failure must not delete or repair evidence automatically.
- Integrity failure should create one deduplicated internal alert.
- Failed integrity must block an export or report from being marked verified.
- Verification output must not expose protected canonical content.

## Alert operations

Alerts should support:

- stable database-enforced deduplication
- occurrence count
- first and last observed timestamps
- ownership
- acknowledgement and containment deadlines
- suppression reason and expiry
- escalation
- reopening with a reason
- resolution reason
- audit history

Critical credential alerts must not be permanently suppressed by ordinary roles.

Metrics must use correct timestamps and denominators, handle unresolved alerts explicitly, exclude customer data and document their meanings.

## AI assistance

AI is advisory only.

- AI must not approve incidents.
- AI must not verify fixes.
- AI must not close incidents.
- AI must not automatically notify customers.
- AI receives masked and minimised context only.
- Restricted AML information must be filtered before provider calls.
- AI output must be validated before storage or display.
- AI-generated controls require human review.
- The application must remain functional when AI is unavailable.

## Backend conventions

- Use typed Python.
- Keep routers thin.
- Put business logic in focused services.
- Avoid duplicate services and oversized modules.
- Use timezone-aware timestamps.
- Use transactions for multi-record state changes.
- Use explicit foreign keys and appropriate indexes.
- Add uniqueness constraints for idempotency and deduplication.
- Avoid circular imports.
- Do not return raw database exceptions to clients.
- Do not use blanket `# noqa` to hide defects.

## Database migrations

- Never edit an already applied migration.
- Create a new Alembic migration.
- Preserve historical data.
- Avoid destructive changes unless explicitly required.
- Test migration from an empty database.
- Test upgrade from the current schema.
- Do not cascade-delete evidence, audit, decision or integrity history.
- Do not report a migration as working unless executed against PostgreSQL.

## Frontend conventions

- Use TypeScript types for API contracts.
- Avoid `any` unless necessary and documented.
- Never store passwords, secrets or raw evidence in browser storage.
- Never render raw sensitive values.
- Preserve backend RBAC.
- Provide loading, empty, error and unauthorised states.
- Do not use colour alone to communicate critical status.
- Match the existing PrivacyTrace-NP theme.
- Do not create fake buttons or dead links.
- Respect `prefers-reduced-motion`.
- Add tests for safety-critical workflows.

## Accessibility

New frontend work must include visible labels, keyboard navigation, logical focus order, visible focus indicators, sufficient contrast, `aria-invalid`, connected error text, accessible names for icon buttons, live status messages and reduced-motion support.

## Static analysis

Backend checks should include:

```bash
python -m compileall backend/app
ruff check backend/app backend/tests
```

Do not ignore errors equivalent to:

```text
E9
F811
F821
F822
F823
```

Frontend checks should use repository-supported commands equivalent to:

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

Inspect `package.json` before assuming exact names.

## PostgreSQL testing

Critical database workflows must use PostgreSQL.

When `REQUIRE_TEST_POSTGRES=1`, critical database tests must fail rather than silently skip when PostgreSQL is unavailable.

Use a dedicated test database. Never reset development or production data.

Reports must distinguish passed, failed, skipped and not run. Skipped tests are not verified behaviour.

## Documentation

Update documentation whenever changing architecture, authentication, registration, RBAC, schema, endpoints, taxonomy, privacy harm, causality, provenance, integrity, alerts, configuration, testing or limitations.

Do not leave README claims that contradict the implementation.

Do not report historical test totals as current results.

## Research integrity

- Do not manufacture results.
- Do not claim perfect performance from one scenario.
- Do not use skipped tests as evidence.
- Do not describe rule scores as calibrated probabilities.
- Clearly identify synthetic evidence.
- Clearly state limitations.
- Do not claim legal compliance, certification or production readiness without evidence.

## Release hygiene

Exclude from release archives:

- `.env`
- `.git`
- `.venv`
- `node_modules`
- build output
- caches
- logs
- runtime uploads
- encrypted runtime evidence
- generated private keys
- real credentials

A release should contain source code, migrations, dependency manifests, documentation, safe synthetic samples and `.env.example`.

## Definition of done

A task is complete only when:

1. Requested behaviour is implemented.
2. Related behaviour remains working.
3. Required migrations are included.
4. Static analysis passes.
5. Relevant backend tests pass.
6. Critical PostgreSQL tests do not skip.
7. Frontend typecheck, tests and build pass when frontend code changed.
8. Raw-data leak checks pass.
9. No secret is committed.
10. Documentation is updated.
11. Limitations are stated.
12. Exact test counts are reported.
13. No unrelated feature was added.

## Completion report

After substantial work, report:

1. What was implemented.
2. Confirmed root causes.
3. Files created and modified.
4. Database migrations.
5. API and schema changes.
6. Static checks.
7. Tests executed.
8. Exact pass, fail and skip counts.
9. Tests not executed and why.
10. Security checks.
11. Known limitations.
12. Deferred work.
13. Final readiness verdict.

Do not claim completion when critical tests are skipped, failed or not run.
