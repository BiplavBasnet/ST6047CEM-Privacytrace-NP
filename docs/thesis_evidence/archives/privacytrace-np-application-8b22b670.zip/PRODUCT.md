# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Primary: security analysts and organisation administrators investigating possible sensitive-data exposure in Nepal digital financial service API logs.

Also: DevSecOps engineers (monitor, ingest, contain), auditors (read-only evidence and audit), developers (evidence/scanner read), viewers (restricted dashboards).

Situation: operational investigation under time pressure, not a marketing site. Users need to know where they are, what is urgent, and what to do next.

## Product Purpose

PrivacyTrace-NP is a live privacy monitoring and incident traceability workspace. It ingests copied log/event streams, masks sensitive values, creates privacy alerts, correlates evidence, ranks likely causes, requires human review, records remediation, verifies fixes through a controlled retest chain, and exports privacy-safe reports.

Success: an investigator can complete Live Exposure → Alert → Incident → Evidence → RCA → Human Review → Remediation → Verification → Report without guessing the next step, without seeing raw secrets, and without the UI inventing workflow truth.

## Positioning

Unlike generic SIEM or scanner dashboards, PrivacyTrace-NP is an evidence-grounded investigation workspace: likely-cause ranking with supporting and contradicting evidence, mandatory human gates, controlled retest (not “test passed = fix verified”), rollback-aware verification, and privacy-safe provenance in the final report.

## Operating Context

Thesis prototype for academic demonstration. Demo seed accounts and synthetic events are development/demo only; company onboarding uses `/setup` and organisation verification. Backend workflow state is authoritative. Frontend never invents stage completion.

Primary investigation surface: `/incidents/:id/:stage` with six user-facing stages (Overview, Likely Cause, Review, Remediation, Verify Fix, Report). Guided Investigation (`/wizard`, `/guided-investigation`) is a labelled demo walkthrough of the same backend workflow.

## Capabilities and Constraints

Capabilities that must remain reachable: live monitor start/stop/synthetic ingest; alert triage/create incident/dismiss; six-stage incident workspace; RCA, evidence graph, counterfactual; human review decisions; AI diagnosis with human-owned remediation; containment and preventive controls; implementation → allowlisted test → controlled retest → verification → outcome; rollback display; report PDF/ZIP and readiness; integration tokens/curl/SOC export; evidence import; ScannerBridge preview/import/correlate; users invite/role/suspend/revoke; audit logs; metrics evaluation; taxonomy; security profile.

Constraints: do not change backend/app, Alembic, API/RBAC/workflow/RCA/remediation/verification/rollback/learning/masking semantics. Do not remove routes. Do not display raw sensitive values. Do not claim proven cause, guaranteed fix, or AI self-approval.

Terminology: backend enums stay (`ControlledRetest`, `FixVerification`, …). User-facing copy uses plain labels with the technical term in tooltip/detail.

## Brand Commitments

Name: PrivacyTrace-NP. Personality: calm, precise, trustworthy, technical, modern, restrained, professional. Incumbent navy `#172826` + teal `#0f766e` + Inter + IBM Plex Mono. Not flashy, cyberpunk, neon, glassmorphic, gamified, or generic AI-dashboard.

## Evidence on Hand

Synthetic demo data only (`INC-SEED-001`, demo users such as `admin@privacytrace.local`). Baseline screenshots: `docs/ux-redesign/before/`. Do not fabricate customer metrics, testimonials, or production claims.

## Product Principles

1. Simplify the experience, not the product capability.
2. One primary next action; backend `next_action` is the source of truth.
3. Progressive disclosure: what matters → what to do → status → short context; advanced on demand.
4. Human gates and privacy masking stay visible and unmistakable.
5. Status is icon + label + color; never color alone.

## Accessibility & Inclusion

Target WCAG 2.2 AA: keyboard, visible focus, labels, dialog/disclosure/tab semantics, skip-to-main, 44px-class touch targets where practical, status not color-only, `prefers-reduced-motion`. Desktop is primary for investigation; essential tasks remain usable at ~1024×768 and ~390×844.
